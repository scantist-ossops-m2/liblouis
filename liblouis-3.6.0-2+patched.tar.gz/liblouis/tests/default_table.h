/* liblouis Braille Translation and Back-Translation Library

Copyright (C) 2016 Swiss Library for the Blind, Visually Impaired and Print Disabled

Copying and distribution of this file, with or without modification,
are permitted in any medium without royalty provided the copyright
notice and this notice are preserved. This file is offered as-is,
without any warranty. */

#define TRANSLATION_TABLE "tables/compress.cti,tables/en-us-g2.ctb"
